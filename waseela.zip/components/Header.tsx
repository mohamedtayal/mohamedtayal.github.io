import React from 'react';
import { TargetIcon, BookOpenIcon, TrophyIcon } from './icons/Icons';

type View = 'dashboard' | 'resources' | 'achievements';

interface HeaderProps {
  currentView: View;
  setView: (view: View) => void;
}

const NavLink: React.FC<{
    icon: React.ReactNode;
    label: string;
    isActive: boolean;
    onClick: () => void;
}> = ({ icon, label, isActive, onClick }) => (
    <button
        onClick={onClick}
        className={`flex items-center gap-2 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
            isActive
                ? 'bg-blue-100 text-blue-700'
                : 'text-slate-500 hover:bg-slate-200 hover:text-slate-800'
        }`}
    >
        {icon}
        <span>{label}</span>
    </button>
);


const Header: React.FC<HeaderProps> = ({ currentView, setView }) => {
  return (
    <header className="bg-white/80 backdrop-blur-lg shadow-sm sticky top-0 z-40">
      <div className="container mx-auto px-4 md:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center gap-3">
            <h1 className="text-2xl font-extrabold text-blue-600">
              وسيلة
            </h1>
            <span className="text-sm text-slate-500 font-medium hidden md:block">Waseela</span>
          </div>
          <nav className="flex items-center gap-2 md:gap-4">
            <NavLink
                icon={<TargetIcon />}
                label="Dashboard"
                isActive={currentView === 'dashboard'}
                onClick={() => setView('dashboard')}
            />
            <NavLink
                icon={<BookOpenIcon />}
                label="Resources"
                isActive={currentView === 'resources'}
                onClick={() => setView('resources')}
            />
            <NavLink
                icon={<TrophyIcon />}
                label="Achievements"
                isActive={currentView === 'achievements'}
                onClick={() => setView('achievements')}
            />
          </nav>
        </div>
      </div>
    </header>
  );
};

export default Header;
