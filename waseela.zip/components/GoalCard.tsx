import React, { useState, useMemo } from 'react';
import { Goal, Milestone } from '../types';
import { TargetIcon, CheckCircleIcon, TrashIcon } from './icons/Icons';

interface GoalCardProps {
  goal: Goal;
  onToggleMilestone: (goalId: number, milestoneId: number) => void;
  onAddMilestone: (goalId: number, milestoneText: string) => void;
  onUpdate: (goal: Goal) => void;
  onDelete: (goalId: number) => void;
}

const GoalCard: React.FC<GoalCardProps> = ({ goal, onToggleMilestone, onAddMilestone, onUpdate, onDelete }) => {
  const [newMilestoneText, setNewMilestoneText] = useState('');

  const progress = useMemo(() => {
    if (goal.milestones.length === 0) return 0;
    const completedCount = goal.milestones.filter(m => m.completed).length;
    return Math.round((completedCount / goal.milestones.length) * 100);
  }, [goal.milestones]);
  
  const isCompleted = progress === 100 && goal.milestones.length > 0;

  const handleAddMilestone = (e: React.FormEvent) => {
    e.preventDefault();
    if (newMilestoneText.trim()) {
      onAddMilestone(goal.id, newMilestoneText);
      setNewMilestoneText('');
    }
  };

  return (
    <div className={`bg-white rounded-lg shadow-md border overflow-hidden transform hover:-translate-y-1 transition-transform duration-300 flex flex-col ${isCompleted ? 'border-green-400' : 'border-slate-200'}`}>
      <div className="p-5 flex-grow">
        <div className="flex justify-between items-start">
            <h3 className="text-lg font-bold text-slate-800 mb-2 pr-2">{goal.title}</h3>
            <button onClick={() => onDelete(goal.id)} className="text-slate-400 hover:text-red-500 transition-colors">
                <TrashIcon className="w-5 h-5" />
            </button>
        </div>
        
        <p className="text-sm text-slate-500 mb-4">{goal.relevance}</p>
        <div className="text-xs text-slate-500 mb-4">
            <p><span className="font-semibold">Measure:</span> {goal.measurement}</p>
            <p><span className="font-semibold">Deadline:</span> {new Date(goal.deadline).toLocaleDateString()}</p>
        </div>

        <div className="mb-4">
          <div className="flex justify-between items-center mb-1">
            <span className="text-sm font-medium text-slate-600">Progress</span>
            <span className={`text-sm font-bold ${isCompleted ? 'text-green-600' : 'text-blue-600'}`}>{progress}%</span>
          </div>
          <div className="w-full bg-slate-200 rounded-full h-2.5">
            <div
              className={`h-2.5 rounded-full transition-all duration-500 ${isCompleted ? 'bg-green-500' : 'bg-blue-600'}`}
              style={{ width: `${progress}%` }}
            ></div>
          </div>
        </div>

        <div>
          <h4 className="font-semibold text-slate-700 mb-2">Milestones</h4>
          <div className="space-y-2 max-h-40 overflow-y-auto pr-2">
            {goal.milestones.length > 0 ? goal.milestones.map(m => (
              <div key={m.id} className="flex items-center gap-3 cursor-pointer group" onClick={() => onToggleMilestone(goal.id, m.id)}>
                <div className="w-5 h-5">
                  {m.completed ? <CheckCircleIcon className="text-green-500" /> : <div className="w-4 h-4 mt-0.5 ml-0.5 border-2 border-slate-300 rounded-full group-hover:border-blue-500 transition-colors" />}
                </div>
                <span className={`flex-1 text-sm ${m.completed ? 'text-slate-400 line-through' : 'text-slate-600 group-hover:text-blue-600'}`}>{m.text}</span>
              </div>
            )) : <p className="text-sm text-slate-400 italic">No milestones yet. Add one below.</p>}
          </div>
        </div>
      </div>
      <div className="bg-slate-50 p-4 border-t border-slate-200">
          <form onSubmit={handleAddMilestone} className="flex gap-2">
            <input
              type="text"
              value={newMilestoneText}
              onChange={(e) => setNewMilestoneText(e.target.value)}
              placeholder="Add a new milestone..."
              className="flex-grow bg-white border border-slate-300 rounded-md px-3 py-1.5 text-sm focus:ring-2 focus:ring-blue-500 focus:outline-none"
            />
            <button type="submit" className="px-3 py-1.5 bg-blue-500 text-white rounded-md text-sm font-semibold hover:bg-blue-600 transition-colors disabled:bg-slate-300" disabled={!newMilestoneText.trim()}>
              Add
            </button>
          </form>
      </div>
    </div>
  );
};

export default GoalCard;
