import React from 'react';
import { Achievement } from '../types';

interface AchievementBadgeProps {
  achievement: Achievement;
}

const AchievementBadge: React.FC<AchievementBadgeProps> = ({ achievement }) => {
  return (
    <div className={`text-center p-4 rounded-lg transition-all duration-300 ${
      achievement.unlocked ? 'bg-white shadow-lg border-yellow-300 border' : 'bg-slate-200'
    }`}>
      <div className={`mx-auto w-16 h-16 flex items-center justify-center rounded-full mb-3 transition-all duration-300 ${
        achievement.unlocked ? 'bg-yellow-100 text-yellow-500' : 'bg-slate-300 text-slate-500'
      }`}>
        <div className={`transform transition-transform ${achievement.unlocked ? 'scale-100' : 'scale-90'}`}>
            {achievement.icon}
        </div>
      </div>
      <h3 className={`font-bold text-md ${achievement.unlocked ? 'text-slate-800' : 'text-slate-600'}`}>
        {achievement.title}
      </h3>
      <p className={`text-xs ${achievement.unlocked ? 'text-slate-600' : 'text-slate-500'}`}>
        {achievement.description}
      </p>
    </div>
  );
};

export default AchievementBadge;
