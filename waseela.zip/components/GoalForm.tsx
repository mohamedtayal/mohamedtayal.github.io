import React, { useState } from 'react';
import { Goal } from '../types';

interface GoalFormProps {
  onAddGoal: (goal: Omit<Goal, 'id' | 'createdAt' | 'milestones'>) => void;
}

const GoalForm: React.FC<GoalFormProps> = ({ onAddGoal }) => {
  const [title, setTitle] = useState('');
  const [measurement, setMeasurement] = useState('');
  const [achievability, setAchievability] = useState('');
  const [relevance, setRelevance] = useState('');
  const [deadline, setDeadline] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !relevance || !deadline) {
      alert('Please fill out at least the title, relevance, and deadline.');
      return;
    }
    onAddGoal({ title, measurement, achievability, relevance, deadline });
    // Reset form
    setTitle('');
    setMeasurement('');
    setAchievability('');
    setRelevance('');
    setDeadline('');
  };

  const today = new Date().toISOString().split('T')[0];

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="text-center">
        <h2 className="text-2xl font-bold text-slate-800">Create a New SMART Goal</h2>
        <p className="text-slate-500 mt-1">Define your objective clearly to set yourself up for success.</p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Specific */}
        <div className="md:col-span-2">
          <label htmlFor="title" className="block text-sm font-bold text-slate-700">
            S - Specific
          </label>
          <p className="text-xs text-slate-500 mb-1">What exactly do you want to achieve?</p>
          <input
            type="text"
            id="title"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="mt-1 block w-full px-3 py-2 bg-white border border-slate-300 rounded-md shadow-sm placeholder-slate-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
            placeholder="e.g., Learn React for web development"
            required
          />
        </div>

        {/* Measurable */}
        <div>
          <label htmlFor="measurement" className="block text-sm font-bold text-slate-700">
            M - Measurable
          </label>
          <p className="text-xs text-slate-500 mb-1">How will you track your progress?</p>
          <input
            type="text"
            id="measurement"
            value={measurement}
            onChange={(e) => setMeasurement(e.target.value)}
            className="mt-1 block w-full px-3 py-2 bg-white border border-slate-300 rounded-md shadow-sm placeholder-slate-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
            placeholder="e.g., Complete 3 projects"
          />
        </div>

        {/* Time-bound */}
        <div>
            <label htmlFor="deadline" className="block text-sm font-bold text-slate-700">
                T - Time-bound
            </label>
            <p className="text-xs text-slate-500 mb-1">What is your target completion date?</p>
            <input
                type="date"
                id="deadline"
                value={deadline}
                onChange={(e) => setDeadline(e.target.value)}
                min={today}
                className="mt-1 block w-full px-3 py-2 bg-white border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                required
            />
        </div>

        {/* Relevant */}
        <div className="md:col-span-2">
          <label htmlFor="relevance" className="block text-sm font-bold text-slate-700">
            R - Relevant
          </label>
          <p className="text-xs text-slate-500 mb-1">Why is this goal important to you?</p>
          <textarea
            id="relevance"
            value={relevance}
            onChange={(e) => setRelevance(e.target.value)}
            rows={3}
            className="mt-1 block w-full px-3 py-2 bg-white border border-slate-300 rounded-md shadow-sm placeholder-slate-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
            placeholder="e.g., To switch to a career in frontend development"
            required
          />
        </div>
        
        {/* Achievable */}
        <div className="md:col-span-2">
          <label htmlFor="achievability" className="block text-sm font-bold text-slate-700">
            A - Achievable
          </label>
          <p className="text-xs text-slate-500 mb-1">What makes this goal realistic for you right now?</p>
          <textarea
            id="achievability"
            value={achievability}
            onChange={(e) => setAchievability(e.target.value)}
            rows={2}
            className="mt-1 block w-full px-3 py-2 bg-white border border-slate-300 rounded-md shadow-sm placeholder-slate-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
            placeholder="e.g., I have 10 hours per week to dedicate to learning."
          />
        </div>

      </div>

      <div className="flex justify-end">
        <button
          type="submit"
          className="w-full md:w-auto inline-flex justify-center py-2 px-6 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
        >
          Set Goal
        </button>
      </div>
    </form>
  );
};

export default GoalForm;
