import React from 'react';
import { Resource } from '../types';
import { BookmarkIcon, VideoCameraIcon, DocumentTextIcon, MicrophoneIcon } from './icons/Icons';

interface ResourceCardProps {
  resource: Resource;
  isBookmarked: boolean;
  onToggleBookmark: (id: number) => void;
}

const ResourceCard: React.FC<ResourceCardProps> = ({ resource, isBookmarked, onToggleBookmark }) => {
    
  const typeIcon = {
    'Article': <DocumentTextIcon className="w-5 h-5" />,
    'Video': <VideoCameraIcon className="w-5 h-5" />,
    'Podcast': <MicrophoneIcon className="w-5 h-5" />,
  }[resource.type];
    
  const categoryColor = {
      'Career': 'bg-blue-100 text-blue-800',
      'Health': 'bg-green-100 text-green-800',
      'Education': 'bg-indigo-100 text-indigo-800',
      'Personal': 'bg-yellow-100 text-yellow-800',
  }[resource.category];

  return (
    <div className="bg-white rounded-lg shadow-md border border-slate-200 p-5 flex flex-col justify-between transition-shadow hover:shadow-lg">
      <div>
        <div className="flex justify-between items-start mb-2">
            <div className="flex items-center gap-2 text-sm text-slate-600">
                <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${categoryColor}`}>
                    {resource.category}
                </span>
                <span className="flex items-center gap-1">
                    {typeIcon} {resource.type}
                </span>
            </div>
          <button onClick={() => onToggleBookmark(resource.id)} className="text-slate-400 hover:text-yellow-500 transition-colors">
            <BookmarkIcon className={`w-6 h-6 ${isBookmarked ? 'text-yellow-500 fill-current' : 'text-slate-400'}`} />
          </button>
        </div>
        <h3 className="text-lg font-bold text-slate-800 mb-2">{resource.title}</h3>
        <p className="text-sm text-slate-500">{resource.description}</p>
      </div>
      <a href={resource.link} target="_blank" rel="noopener noreferrer" className="mt-4 inline-block text-sm font-semibold text-blue-600 hover:text-blue-800 transition-colors">
        Learn More &rarr;
      </a>
    </div>
  );
};

export default ResourceCard;
