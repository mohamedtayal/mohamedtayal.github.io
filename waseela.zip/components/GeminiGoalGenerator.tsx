import React, { useState } from 'react';
import { generateGoalSuggestions } from '../services/geminiService';
import { GoalSuggestion, Goal } from '../types';
import { SparklesIcon, PlusIcon } from './icons/Icons';

interface GeminiGoalGeneratorProps {
    onAddGoal: (goal: Omit<Goal, 'id' | 'createdAt' | 'milestones'>) => void;
}

const GeminiGoalGenerator: React.FC<GeminiGoalGeneratorProps> = ({ onAddGoal }) => {
    const [idea, setIdea] = useState('');
    const [suggestions, setSuggestions] = useState<GoalSuggestion[]>([]);
    const [status, setStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');
    const [error, setError] = useState('');

    const isApiKeyMissing = !process.env.API_KEY || process.env.API_KEY === "YOUR_API_KEY_IS_MISSING";

    const handleGenerate = async () => {
        if (!idea.trim() || isApiKeyMissing) return;
        setStatus('loading');
        setSuggestions([]);
        try {
            const result = await generateGoalSuggestions(idea);
            setSuggestions(result);
            setStatus('success');
        } catch (err) {
            setStatus('error');
            setError(err instanceof Error ? err.message : 'An unknown error occurred.');
        }
    };

    const handleAddSuggestion = (suggestion: GoalSuggestion) => {
        const deadline = new Date();
        deadline.setDate(deadline.getDate() + suggestion.timeBoundDays);

        const newGoal: Omit<Goal, 'id' | 'createdAt' | 'milestones'> = {
            title: suggestion.specific,
            measurement: suggestion.measurable,
            achievability: suggestion.achievable,
            relevance: suggestion.relevant,
            deadline: deadline.toISOString().split('T')[0],
        };
        onAddGoal(newGoal);
        // Optional: remove the added suggestion from the list
        setSuggestions(prev => prev.filter(s => s.specific !== suggestion.specific));
    };

    return (
        <div className="bg-white rounded-lg shadow-md border border-slate-200 p-6">
            <div className="flex items-center gap-3 mb-4">
                <SparklesIcon className="w-8 h-8 text-blue-500" />
                <div>
                    <h3 className="text-xl font-bold text-slate-800">Need Inspiration?</h3>
                    <p className="text-slate-500">Let our AI assistant help you craft the perfect goal.</p>
                </div>
            </div>

            {isApiKeyMissing ? (
                 <div className="text-center p-4 border border-red-200 bg-red-50 rounded-lg">
                    <p className="text-red-700 font-semibold">AI Assistant Disabled</p>
                    <p className="text-red-600 text-sm">A valid Gemini API key is not configured. Please set the API_KEY environment variable to use this feature.</p>
                </div>
            ) : (
                <>
                    <div className="flex flex-col sm:flex-row gap-2 mb-4">
                        <input
                            type="text"
                            value={idea}
                            onChange={(e) => setIdea(e.target.value)}
                            placeholder="e.g., 'get fit' or 'learn a new skill'"
                            className="flex-grow bg-white border border-slate-300 rounded-md px-3 py-2 text-base focus:ring-2 focus:ring-blue-500 focus:outline-none"
                        />
                        <button
                            onClick={handleGenerate}
                            disabled={status === 'loading' || !idea.trim()}
                            className="flex justify-center items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg font-semibold hover:bg-blue-700 transition-colors shadow-sm disabled:bg-slate-400 disabled:cursor-not-allowed"
                        >
                            {status === 'loading' ? 'Generating...' : 'Generate Ideas'}
                        </button>
                    </div>

                    {status === 'loading' && (
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
                           {[...Array(3)].map((_, i) => (
                                <div key={i} className="bg-slate-100 rounded-lg p-4 animate-pulse">
                                    <div className="h-5 bg-slate-300 rounded w-3/4 mb-3"></div>
                                    <div className="h-3 bg-slate-300 rounded w-full mb-2"></div>
                                    <div className="h-3 bg-slate-300 rounded w-5/6"></div>
                                </div>
                           ))}
                        </div>
                    )}

                    {status === 'error' && <p className="text-red-500 text-sm mt-2">{error}</p>}
                    
                    {status === 'success' && suggestions.length > 0 && (
                        <div className="mt-6">
                            <h4 className="font-semibold text-slate-700 mb-3">Here are a few suggestions:</h4>
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                {suggestions.map((s, index) => (
                                    <div key={index} className="bg-blue-50 border border-blue-200 rounded-lg p-4 flex flex-col justify-between">
                                        <div>
                                            <p className="font-bold text-blue-900">{s.specific}</p>
                                            <p className="text-sm text-blue-700 mt-1">{s.relevant}</p>
                                        </div>
                                        <button onClick={() => handleAddSuggestion(s)} className="mt-4 flex items-center justify-center gap-1 w-full text-sm font-semibold bg-white text-blue-600 border border-blue-300 rounded-md px-3 py-1.5 hover:bg-blue-100 transition-colors">
                                            <PlusIcon className="w-4 h-4" />
                                            Add This Goal
                                        </button>
                                    </div>
                                ))}
                            </div>
                        </div>
                    )}
                </>
            )}
        </div>
    );
};

export default GeminiGoalGenerator;