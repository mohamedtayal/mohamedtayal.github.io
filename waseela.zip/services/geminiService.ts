import { GoogleGenAI } from "@google/genai";
import { GoalSuggestion } from '../types';

if (!process.env.API_KEY) {
  // This is a placeholder check. In a real environment, the key should be set.
  // The UI will handle the case where the key is missing.
  console.warn("API_KEY environment variable not set. Gemini features will be disabled.");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || "YOUR_API_KEY_IS_MISSING" });

export const generateGoalSuggestions = async (userInput: string): Promise<GoalSuggestion[]> => {
    const prompt = `You are an expert life coach. A user wants to achieve this goal: "${userInput}". Generate 3 distinct SMART goals based on this idea. For each goal, provide a 'specific' statement, a 'measurable' metric, an 'achievable' reason, a 'relevant' reason, and a suggested 'timeBoundDays' as a number of days from now. Respond ONLY with a valid JSON array of objects with keys: "specific", "measurable", "achievable", "relevant", "timeBoundDays". Do not include any other text or markdown.`;

    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash-preview-04-17",
            contents: prompt,
            config: {
                responseMimeType: "application/json",
            },
        });
        
        let jsonStr = response.text.trim();
        const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s;
        const match = jsonStr.match(fenceRegex);
        if (match && match[2]) {
            jsonStr = match[2].trim();
        }

        const parsedData: GoalSuggestion[] = JSON.parse(jsonStr);
        return parsedData;

    } catch (error) {
        console.error("Failed to generate goal suggestions:", error);
        throw new Error("Could not get suggestions from AI. Please check your prompt or API key.");
    }
};
